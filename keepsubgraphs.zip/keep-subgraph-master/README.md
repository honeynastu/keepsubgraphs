﻿#It was used for scientific purposes to penetrate and understand the work at the subgraph level. Thank you for providing materials in the public domain of the following users.
@juliankoh](https://github.com/juliankoh)
@suntzu93](https://github.com/suntzu93
@Tibike6](https://github.com/Tibike6)
+ @miracle2k package.json